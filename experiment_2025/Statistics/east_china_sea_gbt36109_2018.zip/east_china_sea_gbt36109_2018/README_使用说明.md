# 东海浮标筛选掩膜（GB/T 36109—2018 描述的近似实现）

制作日期：2026-10-28。坐标：WGS84 / EPSG:4326，顺序为经度、纬度，单位为十进制度。

## 结论与依据

GB/T 36109—2018《中国气象产品地理分区》现行。全国标准信息公共服务平台记载其于2025-08-04复审，结论为继续有效。

本次逐页核对了国家标准全文公开系统的表2（印刷页2）及图A.2（印刷页5）；另核对北斗官网BD 440086—2022附录A表A.1（印刷页18–19），其中明确参考GB/T 36109—2018。保存的官方预览页见`sources/gb_official_page_05.png`和`sources/gb_official_page_08.png`，文件名数字为在线预览顺序。

以下为释义，不是逐字全文引用：

| 边界或分区 | 标准含义 | 本掩膜的实现 |
|---|---|---|
| 北界，与黄海分界 | 长江口北岸启东角至济州岛西南角的连线 | 选取近似地名坐标后作经纬度平面直线 |
| 东北界 | 济州岛、五岛列岛、长崎一线 | 按地名设置近似控制点并连接 |
| 东及东南界 | 九州岛、琉球群岛方向与太平洋分隔 | 以九州、屋久岛、吐噶喇、奄美、冲绳方向的折线近似；不是逐岛精细海域界线 |
| 西界 | 中国大陆海岸 | 扣除Natural Earth陆地多边形 |
| 西南界 | 平潭岛至台湾北端富贵角连线，与台湾海峡分隔 | 近似地名控制点连线，向大陆一侧用陆地裁切 |
| 南界 | 东海南部至25.0°N；台湾以东洋面的北界沿25.0°N至琉球群岛 | 台湾东北侧至东侧岛链采用25°N纬线 |
| 东海北部/南部 | 29.5°N分界 | 点筛选时纬度≥29.5°N归北部，其余归南部 |

## 精度与适用范围（请先读）

**这是自制的近似分析掩膜，不是国家发布的数字边界，也不能声称与国标附图逐点一致。** 本次核验到的表格和附图没有提供所有转折点的精确坐标，不能据此产生唯一的精密矢量边界。所有自定控制点均保存在`boundary_control_points.csv`；代码中也完整列出。

海岸线使用Natural Earth **1:10m land v5.1.1**；这里的10m表示**1:1000万比例尺，绝非10米空间分辨率**。陆地和主要岛屿已扣除，部分小岛、港池、河口及新近围填海细节仍会有误差。构建后保留最大连通海域以去掉不相连的内陆水面。

0.01°网格约为1公里量级，仅表示采样间隔，**不表示边界达到1公里精度**。沿琉球岛链的折线和东北界为概化边界，局部差异可达数十公里。对这些边缘海域作严格归属判定时，应回看标准图、结合业务海区矢量或主管部门数据复核。

筛选脚本默认给距掩膜外边界（含海岸和岛屿孔洞）约10公里内的点加复核标记。**10公里是便于检查的启发式阈值，不是误差上限或置信区间**；可用`--review-km 30`扩大范围。复核文件同时含边界内外的点，避免只检查已入选浮标。距离用29.5°N附近的等距圆柱近似换算，只作提示。内部29.5°N分界不计入外边界复核距离。

本掩膜表示气象地理海区，不执行国家管辖海域、领海或专属经济区裁切。检索发现Marine Regions的IHO东海范围南至约24.06°N，不能直接替代本标准的东海海区；本成果**未采用IHO几何**。

## 文件

| 文件 | 用途 |
|---|---|
| `east_china_sea_gbt36109_approx.geojson` | 推荐：东海整体矢量掩膜，直接判断浮标坐标 |
| 同名`.shp/.shx/.dbf/.prj/.cpg` | ArcGIS/QGIS可加载的Shapefile；5个文件应放在同一目录 |
| `east_china_sea_subregions_approx.geojson` | 东海北部与南部两要素，公共分界线为29.5°N |
| `east_china_sea_mask_0p01deg.nc` | NetCDF规则网格：`mask(lat,lon)`，0区外、1区内；`region`为0区外、1北部、2南部 |
| `east_china_sea_mask_0p01deg.npz` | NumPy压缩版，同样包含lon、lat、mask、region |
| `east_china_sea_mask_preview.png` | 范围预览，便于核对 |
| `filter_buoys.py` | CSV逐位置筛选工具，另可导入`classify()` |
| `boundary_control_points.csv` | 控制点及性质；含只用于闭合、随后被陆地裁去的辅助点 |
| `build_mask.py` | 从随附源数据重建掩膜、网格和预览图 |
| `validation_results.json` | 几何、内外样例、网格一致性检查记录 |
| `sources/` | 原始陆地压缩包、标准官方预览页及交叉核验文件 |

网格范围：118–132°E、24–34°N；单元中心经度118.005–131.995°E，纬度24.005–33.995°N，步长0.01°，纬度升序。网格范围内区外也为0。向此范围之外插值必须显式设区外为0或缺测，不能外推边缘值。

## 直接筛选浮标CSV

安装依赖：

```powershell
python -m pip install numpy pandas shapely
```

在本文件夹运行，输入列假设名为`longitude`和`latitude`：

```powershell
python filter_buoys.py buoys.csv --lon longitude --lat latitude --out results
```

如果列名是`LON`、`LAT`：

```powershell
python filter_buoys.py buoys.csv --lon LON --lat LAT --out results --review-km 30
```

输出：

- `results/inside.csv`：位于近似东海掩膜内的记录。
- `results/all_annotated.csv`：所有输入记录，新增区内/区外、南北部、边界复核及坐标有效性字段。
- `results/boundary_review.csv`：距掩膜外边界约指定距离内的记录，**含区内及区外**。
- `results/invalid_coordinates.csv`：缺测、非数值及超出经纬度取值范围的记录。

脚本接受-180…180°或0…360°经度；0…360°中的>180°转换到西经。纬度需为-90…90°。输入应为WGS84十进制度，不能直接输入度分秒文本或地图偏移坐标。轮廓边界上的点纳入；29.5°N上的点归北部。整数编码或业务缺测码若恰好落入合法坐标范围，须先按数据说明清洗。

对漂流浮标，默认筛选**每条观测位置**；同一浮标可先后进出区域。若需“曾进入东海”的浮标编号，可从`inside.csv`按浮标ID去重；不要仅凭首个位置定义整条轨迹归属。

## 在Python中直接使用

```python
from filter_buoys import classify
inside, region, near_boundary, valid = classify(lon_array, lat_array)
selected = observations[inside]   # observations需与位置数组逐条对应
```

也可直接读取GeoJSON，用Shapely的`covers`逐点判断。**推荐对浮标原始坐标执行矢量判断**，避免最近邻网格在边缘引入约半个网格的偏移。

```python
import json
from shapely.geometry import shape, Point
with open('east_china_sea_gbt36109_approx.geojson', encoding='utf-8') as f:
    polygon = shape(json.load(f)['features'][0]['geometry'])
inside = polygon.covers(Point(123.0, 28.0))
```

网格读取：

```python
import xarray as xr
ds = xr.open_dataset('east_china_sea_mask_0p01deg.nc')
# 与别的模型网格不一致时，应对目标格点坐标重新执行classify，
# 不要把此数组按下标直接乘到另一套网格上。
```

重建需要：`python -m pip install numpy shapely pyshp scipy xarray matplotlib`，随后运行`python build_mask.py`。随附源文件使重建不依赖在线服务。

## 可核验来源

1. 国家标准全文公开系统，GB/T 36109—2018状态及在线全文入口：
   https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=213D318C8D7B8298ABBA88C34DE78697
2. 全国标准信息公共服务平台，复审日期与继续有效结论：
   https://std.samr.gov.cn/gb/search/gbDetailed?id=XT1FqkcZGaQ%3D&mode=p
3. 北斗官网，BD 440086—2022《基于北斗的海上安全信息传输要求》，附录A表A.1：
   https://www.beidou.gov.cn/yw/xwzx/202212/W020221231599398975071.pdf
   已从官网HTTP入口下载完整PDF，本地为`sources/BD440086_2022_official.pdf`。
4. Natural Earth，Land 1:10m v5.1.1（陆地与主要岛屿）：
   https://www.naturalearthdata.com/downloads/10m-physical-vectors/10m-land/
   数据：https://naturalearth.s3.amazonaws.com/10m_physical/ne_10m_land.zip
   使用条款：https://www.naturalearthdata.com/about/terms-of-use/ （公有领域）
5. Marine Regions，Eastern China Sea / MRGID4302（仅比较定义，未用于本掩膜几何）：
   https://www.marineregions.org/gazetteer.php?p=details&id=4302
   其IHO数据来源为IHO 1953 S-23；页面南界约24.0576°N，与本需求不同。

本成果尚未应用到用户实际浮标资料；随附的验证位置为明确标记的人工样例，不能当作真实浮标站点。
