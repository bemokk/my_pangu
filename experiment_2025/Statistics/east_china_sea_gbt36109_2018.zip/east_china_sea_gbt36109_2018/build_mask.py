"""Build an explicitly approximate GB/T 36109-2018 East China Sea mask.

Run from any directory. Dependencies: numpy shapely pyshp scipy xarray matplotlib.
The standard specifies no coordinate list. All named-point coordinates below
are analyst choices for reproducibility, not coordinates issued by the standard.
"""
from pathlib import Path
import json, csv, zipfile, shutil, hashlib
import numpy as np
import shapefile
import shapely
from shapely.geometry import Polygon, box, shape, mapping, MultiPolygon
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
import xarray as xr

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'sources'
SRC.mkdir(exist_ok=True)
OLD = ROOT.parent / 'east_china_sea_mask' / 'sources'
for name in ['ne_10m_land.zip', 'gb_official_page_05.png', 'gb_official_page_08.png', 'BD440086_2022_official.pdf']:
    if not (SRC/name).exists():
        shutil.copy2(OLD/name, SRC/name)

# Sequence clockwise along the seaward boundary, then back inside mainland.
# Named coast anchors and island-chain bends are approximate analyst picks.
controls = [
 ('qidong','启东角/长江口北角',121.90,31.70,'approx_named_anchor'),
 ('jeju_sw','济州岛西南角',126.16,33.20,'approx_named_anchor'),
 ('goto','五岛列岛',128.65,32.65,'approx_named_anchor'),
 ('nagasaki','长崎附近',129.87,32.75,'approx_named_anchor'),
 ('kyushu_w1','九州西岸包络辅助点',130.20,32.15,'approx_coast_envelope'),
 ('kyushu_w2','九州西岸包络辅助点',130.15,31.40,'approx_coast_envelope'),
 ('kyushu_s','九州南部',130.67,31.00,'approx_island_chain'),
 ('yakushima','屋久岛附近',130.50,30.35,'approx_island_chain'),
 ('tokara_n','吐噶喇列岛北段',129.95,29.90,'approx_island_chain'),
 ('tokara_s','吐噶喇列岛南段',129.55,29.00,'approx_island_chain'),
 ('amami','奄美群岛附近',129.30,28.25,'approx_island_chain'),
 ('okinawa_n','冲绳岛北段附近',128.25,26.85,'approx_island_chain'),
 ('okinawa_s','冲绳岛南段附近',127.65,26.15,'approx_island_chain'),
 ('east_25n','琉球群岛方向与25N交点',126.30,25.00,'approx_longitude_exact_latitude'),
 ('taiwan_25n','台湾东北岸方向与25N交点',121.96,25.00,'approx_longitude_exact_latitude'),
 ('taiwan_ne','台湾东北岸辅助点',121.95,25.13,'approx_coast_envelope'),
 ('taiwan_n','台湾北岸辅助点',121.75,25.30,'approx_coast_envelope'),
 ('fugui','富贵角',121.535,25.300,'approx_named_anchor'),
 ('pingtan','平潭岛北部',119.780,25.670,'approx_named_anchor'),
 ('inland1','大陆内陆闭合辅助点',118.80,26.20,'closure_only_removed_by_land'),
 ('inland2','大陆内陆闭合辅助点',119.00,28.00,'closure_only_removed_by_land'),
 ('inland3','大陆内陆闭合辅助点',120.10,30.50,'closure_only_removed_by_land'),
 ('inland4','大陆内陆闭合辅助点',121.00,31.75,'closure_only_removed_by_land'),
]
with (ROOT/'boundary_control_points.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['id','name_zh','longitude','latitude','status']);w.writerows(controls)

env = Polygon([(r[2],r[3]) for r in controls])
assert env.is_valid
with zipfile.ZipFile(SRC/'ne_10m_land.zip') as z:
    r=shapefile.Reader(shp=z.open('ne_10m_land.shp'),shx=z.open('ne_10m_land.shx'),dbf=z.open('ne_10m_land.dbf'))
    land_parts=[]
    clip=box(117,23,133,35)
    for s in r.iterShapes():
        b=s.bbox
        if b[2]<117 or b[0]>133 or b[3]<23 or b[1]>35: continue
        g=shapely.make_valid(shape(s.__geo_interface__))
        land_parts.append(g.intersection(clip))
land=unary_union(land_parts)
g=shapely.make_valid(env.difference(land))
# Ignore disconnected inland waters or artifacts introduced by the envelope.
parts=list(g.geoms) if isinstance(g,MultiPolygon) else [g]
sea=max(parts,key=lambda x:x.area)
sea=orient(sea,sign=1)
north=sea.intersection(box(110,29.5,140,40))
south=sea.intersection(box(110,20,140,29.5))

COMMON=dict(standard='GB/T 36109-2018', basis='Table 2; Figure A.2',
    status='analyst-generated approximate reconstruction; NOT official digital boundary',
    coordinates='WGS84 longitude,latitude in decimal degrees',
    coastline='Natural Earth 1:10m land v5.1.1; map scale 1:10,000,000, NOT 10 metres',
    interpolation='straight segments in lon/lat between documented control points',
    boundary_rule='covers; latitude >=29.5 assigned north in point classification',
    review_buffer_km=10,created='2026-10-28')
def write_geo(path,features):
    obj={'type':'FeatureCollection','features':[{'type':'Feature','properties':{**COMMON,**p},'geometry':mapping(g)} for p,g in features]}
    path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
write_geo(ROOT/'east_china_sea_gbt36109_approx.geojson',[({'region':'east_china_sea','name_zh':'东海'},sea)])
write_geo(ROOT/'east_china_sea_subregions_approx.geojson',[
 ({'region':'north','name_zh':'东海北部','code':1},north),({'region':'south','name_zh':'东海南部','code':2},south)])
write_geo(SRC/'land_context_clipped.geojson',[({'region':'land_context'},land)])

# Grid cell centres; these coordinates are NOT a buoy lookup grid.
lon=np.round(np.arange(118.005,132,0.01),6)
lat=np.round(np.arange(24.005,34,0.01),6)
xx,yy=np.meshgrid(lon,lat)
shapely.prepare(sea)
inside=shapely.intersects_xy(sea,xx,yy)
region=np.where(inside,np.where(yy>=29.5,1,2),0).astype('int8')
ds=xr.Dataset({'mask':(('lat','lon'),inside.astype('int8')),
               'region':(('lat','lon'),region),
               'lon_bnds':(('lon','bnds'),np.column_stack([lon-.005,lon+.005])),
               'lat_bnds':(('lat','bnds'),np.column_stack([lat-.005,lat+.005])),
               'crs':((),np.int32(0))},coords={'lon':lon,'lat':lat},attrs={
    'title':'Approximate East China Sea mask interpreted from GB/T 36109-2018',
    'Conventions':'CF-1.8','source':'GB/T 36109-2018 Table 2 / Fig A.2; Natural Earth land v5.1.1',
    'history':'Created 2026-10-28; analyst-generated approximation, not official digital boundary',
    'boundary_interpolation':'linear in lon/lat; approximate named anchors; see boundary_control_points.csv',
    'grid_note':'0.01 degree cell-centre sampling; grid spacing is NOT boundary accuracy',
    'point_filter_note':'Use GeoJSON covers on actual buoy coordinates; do not use nearest grid cell for edge decisions.'})
ds.lon.attrs.update(standard_name='longitude',units='degrees_east',bounds='lon_bnds',axis='X')
ds.lat.attrs.update(standard_name='latitude',units='degrees_north',bounds='lat_bnds',axis='Y')
ds.crs.attrs.update(grid_mapping_name='latitude_longitude',epsg_code='EPSG:4326',semi_major_axis=6378137.,inverse_flattening=298.257223563)
ds['mask'].attrs.update(long_name='inside approximate East China Sea at cell centre',flag_values=np.array([0,1],dtype='int8'),flag_meanings='outside inside',grid_mapping='crs')
ds['region'].attrs.update(long_name='East China Sea subregion',flag_values=np.array([0,1,2],dtype='int8'),flag_meanings='outside north south',grid_mapping='crs')
ds.to_netcdf(ROOT/'east_china_sea_mask_0p01deg.nc',engine='scipy')
np.savez_compressed(ROOT/'east_china_sea_mask_0p01deg.npz',lon=lon,lat=lat,mask=inside,region=region)

# A GIS-friendly shapefile as well as GeoJSON; all parts use ESRI ring order.
w=shapefile.Writer(str(ROOT/'east_china_sea_gbt36109_approx'),shapeType=shapefile.POLYGON,encoding='utf-8')
w.field('name','C',40);w.field('status','C',60)
s=orient(sea,sign=-1)
w.poly([list(s.exterior.coords)]+[list(r.coords) for r in s.interiors])
w.record('East China Sea','Approximate GB/T36109-2018 reconstruction');w.close()
(ROOT/'east_china_sea_gbt36109_approx.prj').write_text('GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]')
(ROOT/'east_china_sea_gbt36109_approx.cpg').write_text('UTF-8')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch,Patch
from matplotlib.path import Path as MPath
from matplotlib import font_manager
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists(): font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']='Microsoft YaHei'
def patch(poly,ax,color,edge,lw=0.7):
    if poly.geom_type!='Polygon':
        for item in poly.geoms:
            if item.geom_type in ['Polygon','MultiPolygon']: patch(item,ax,color,edge,lw)
        return
    poly=orient(poly,1)
    verts=[];codes=[]
    for r in [poly.exterior,*poly.interiors]:
        v=list(r.coords);verts.extend(v);codes.extend([MPath.MOVETO]+[MPath.LINETO]*(len(v)-2)+[MPath.CLOSEPOLY])
    ax.add_patch(PathPatch(MPath(verts,codes),facecolor=color,edgecolor=edge,lw=lw))
fig,ax=plt.subplots(figsize=(10.5,8.6),dpi=180)
fig.patch.set_facecolor('#ffffff');ax.set_facecolor('#edf5fa')
patch(land,ax,'#e0ded7','#9b9e9a',.5)
patch(north,ax,'#83bdd3','#26718d',1)
patch(south,ax,'#b1d6b2','#4b8c66',1)
ax.plot([119,131],[29.5,29.5],color='#5c6670',ls='--',lw=.8)
for idx,dx,dy in [(0,-1.3,.3),(1,-1.2,.4),(2,-.3,.45),(3,.3,.3),(17,.2,-.45),(18,-1.5,-.5)]:
    _,name,x,y,_=controls[idx];ax.plot(x,y,'o',ms=3,color='#3b4651');ax.annotate(name,(x,y),(x+dx,y+dy),fontsize=8.5,arrowprops={'arrowstyle':'-','lw':.6,'color':'#5b6670'})
ax.text(123.4,31.4,'东海北部',fontsize=15,color='#185c76')
ax.text(123,27.7,'东海南部',fontsize=15,color='#32634a')
ax.text(120.1,28.2,'中国大陆',fontsize=12,color='#666963',rotation=60)
ax.text(120.4,24.35,'台湾岛',fontsize=10,color='#666963')
ax.text(127.7,28,'琉球群岛',fontsize=10,color='#666963',rotation=58)
ax.text(123.4,29.65,'29.5°N',fontsize=9,color='#4c5660')
ax.set(xlim=(118.5,132),ylim=(24,34),xlabel='经度 / °E',ylabel='纬度 / °N')
ax.set_aspect(1/np.cos(np.deg2rad(29)))
ax.grid(alpha=.2);ax.set_axisbelow(True)
ax.set_title('东海浮标筛选掩膜\n按 GB/T 36109—2018 表2描述构建的近似边界',loc='left',fontsize=16,pad=18)
fig.text(.12,.04,'海岸线：Natural Earth 1:10m land v5.1.1（1:1000万比例尺）\n自制近似边界；岛链间采用折线。距外边界或海岸约10 km内的点建议复核；示意图不表示管辖范围。',fontsize=9,color='#586570')
fig.subplots_adjust(bottom=.16,top=.86)
fig.savefig(ROOT/'east_china_sea_mask_preview.png',dpi=180)
plt.close(fig)
summary={'geometry_valid':sea.is_valid,'bounds_lonlat':sea.bounds,'grid_shape_lat_lon':inside.shape,
         'inside_grid_centres':int(inside.sum()),'north_cells':int((region==1).sum()),'south_cells':int((region==2).sum()),
         'removed_disconnected_parts':len(parts)-1,'polygon_area_deg2':sea.area}
(ROOT/'build_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
