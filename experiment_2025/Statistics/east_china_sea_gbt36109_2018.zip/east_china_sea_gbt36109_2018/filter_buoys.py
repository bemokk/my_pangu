"""Filter CSV buoy positions using actual coordinates and a GeoJSON polygon.

pip install numpy pandas shapely
python filter_buoys.py buoys.csv --lon longitude --lat latitude --out results
"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import shapely
from shapely.geometry import shape
from shapely.affinity import scale

DEFAULT=Path(__file__).with_name('east_china_sea_gbt36109_approx.geojson')

def classify(lon,lat,mask_path=DEFAULT,review_km=10.):
    """Return (inside, region, near_external_boundary, valid).

    Shapes broadcast; lon -180..180 or 0..360; lat -90..90; decimal degrees.
    Boundary included. 29.5N assigned north. The review distance uses an
    equirectangular approximation centred on 29.5N, NOT a survey distance.
    """
    if review_km<0: raise ValueError('review_km must be non-negative')
    lon,lat=np.broadcast_arrays(np.asarray(lon,dtype=float),np.asarray(lat,dtype=float))
    valid=np.isfinite(lon)&np.isfinite(lat)&(lon>=-180)&(lon<=360)&(lat>=-90)&(lat<=90)
    lon=np.where(lon>180,lon-360,lon)
    x=np.where(valid,lon,0);y=np.where(valid,lat,0)
    obj=json.loads(Path(mask_path).read_text(encoding='utf-8'))
    poly=shape(obj['features'][0]['geometry'])
    shapely.prepare(poly)
    inside=valid&shapely.intersects_xy(poly,x,y)
    region=np.where(inside,np.where(y>=29.5,1,2),0).astype('int8')
    sx=111.32*np.cos(np.deg2rad(29.5));sy=111.32
    boundary=scale(poly.boundary,xfact=sx,yfact=sy,origin=(0,0))
    shapely.prepare(boundary)
    near=np.zeros(valid.shape,dtype=bool)
    # Compute distances only in the region's padded bounding box.
    a,b,c,d=poly.bounds
    candidates=valid&(x>=a-review_km/sx)&(x<=c+review_km/sx)&(y>=b-review_km/sy)&(y<=d+review_km/sy)
    if np.any(candidates):
        pts=shapely.points(x[candidates]*sx,y[candidates]*sy)
        near[candidates]=shapely.dwithin(boundary,pts,review_km)
    return inside,region,near,valid

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('csv',type=Path)
    ap.add_argument('--lon',default='longitude');ap.add_argument('--lat',default='latitude')
    ap.add_argument('--mask',type=Path,default=DEFAULT)
    ap.add_argument('--out',type=Path,default=Path('filtered_buoys'))
    ap.add_argument('--encoding',default='utf-8-sig')
    ap.add_argument('--review-km',type=float,default=10.)
    args=ap.parse_args()
    df=pd.read_csv(args.csv,encoding=args.encoding)
    x=pd.to_numeric(df[args.lon],errors='coerce').to_numpy()
    y=pd.to_numeric(df[args.lat],errors='coerce').to_numpy()
    inside,region,near,valid=classify(x,y,args.mask,args.review_km)
    reserved=['in_east_china_sea','east_sea_region','near_mask_boundary','valid_coordinates']
    if set(reserved)&set(df.columns): raise ValueError('Output column names already exist in input CSV')
    df['in_east_china_sea']=inside
    df['east_sea_region']=pd.Series(region).map({0:'outside',1:'north',2:'south'}).to_numpy()
    df['near_mask_boundary']=near;df['valid_coordinates']=valid
    args.out.mkdir(parents=True,exist_ok=True)
    for name,rows in [('all_annotated',df),('inside',df[inside]),('boundary_review',df[near]),('invalid_coordinates',df[~valid])]:
        rows.to_csv(args.out/f'{name}.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'rows':len(df),'inside':int(inside.sum()),'north':int((region==1).sum()),'south':int((region==2).sum()),'boundary_review':int(near.sum()),'invalid':int((~valid).sum())},ensure_ascii=False))
if __name__=='__main__':main()
