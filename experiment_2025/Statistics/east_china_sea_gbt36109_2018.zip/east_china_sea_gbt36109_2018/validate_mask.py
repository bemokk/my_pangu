"""Meaningful geometry / classification / serialization checks, no real buoys."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import shapely
from shapely.geometry import shape,Point
import xarray as xr
import shapefile
from filter_buoys import classify

P=Path(__file__).resolve().parent
poly=shape(json.loads((P/'east_china_sea_gbt36109_approx.geojson').read_text(encoding='utf-8'))['features'][0]['geometry'])
cases=[('north_open_sea',123,31,True,1),('south_open_sea',123,28,True,2),
       ('north_of_yellow_sea_boundary',123,34,False,0),('taiwan_strait',120,24.5,False,0),
       ('east_of_taiwan_below_25n',123,24.5,False,0),('pacific',132,28,False,0),
       ('mainland_hangzhou',120.15,30.27,False,0),('taiwan_land',121,24,False,0),
       ('okinawa_land',127.75,26.4,False,0),('on_internal_split',123,29.5,True,1),
       ('above_split',123,29.5001,True,1),('below_split',123,29.4999,True,2),
       ('missing_longitude',float('nan'),28,False,0),('invalid_longitude',999,28,False,0),
       ('invalid_latitude',123,99,False,0),('west_longitude',-120,28,False,0),
       ('equivalent_0_360_west_longitude',240,28,False,0)]
out=[]
for name,x,y,expected,r in cases:
    inside,region,near,valid=classify([x],[y])
    assert bool(inside[0])==expected,(name,inside)
    assert int(region[0])==r,(name,region)
    out.append({'name':name,'longitude':x if np.isfinite(x) else None,'latitude':y,'inside':bool(inside[0]),'region':int(region[0]),'passed':True})
# A known constructed open-water boundary and points immediately on both sides.
for y,expected in [(25.,True),(25.00001,True),(24.99999,False)]:
    a,_,near,_=classify([124.],[y]);assert bool(a[0])==expected;assert near[0]
assert poly.is_valid and not poly.is_empty
subs=json.loads((P/'east_china_sea_subregions_approx.geojson').read_text(encoding='utf-8'))['features']
n,s=[shape(f['geometry']) for f in subs]
assert n.union(s).symmetric_difference(poly).area<1e-9
assert n.intersection(s).area<1e-9
with xr.open_dataset(P/'east_china_sea_mask_0p01deg.nc') as d:
    assert d['mask'].shape==(1000,1400)
    assert (np.diff(d.lat)>0).all() and (np.diff(d.lon)>0).all()
    rng=np.random.default_rng(36109)
    ii=rng.integers(0,1000,2500);jj=rng.integers(0,1400,2500)
    a,r,_,_=classify(d.lon.values[jj],d.lat.values[ii])
    assert np.array_equal(a,d['mask'].values[ii,jj].astype(bool))
    assert np.array_equal(r,d['region'].values[ii,jj])
    with np.load(P/'east_china_sea_mask_0p01deg.npz') as z:
        assert np.array_equal(d['mask'].values,z['mask'])
        assert np.array_equal(d['region'].values,z['region'])
    cells=int(d['mask'].sum())
rr=shapefile.Reader(str(P/'east_china_sea_gbt36109_approx'))
sp=shape(rr.shape(0).__geo_interface__)
assert sp.symmetric_difference(poly).area<1e-10
result={'geometry_valid':True,'subregion_union_matches':True,'subregion_area_overlap':0,
        'grid_sample_checks':2500,'grid_and_point_results_match':True,'npz_nc_match':True,
        'shapefile_geojson_match':True,'boundary_included':True,'invalid_coordinates_rejected':True,
        'inside_grid_centres':cells,'synthetic_cases':out}
(P/'validation_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
df=pd.DataFrame([{'id':row[0],'longitude':row[1],'latitude':row[2]} for row in cases])
df.to_csv(P/'example_synthetic_positions.csv',index=False)
print(json.dumps({k:v for k,v in result.items() if k!='synthetic_cases'},indent=2))
