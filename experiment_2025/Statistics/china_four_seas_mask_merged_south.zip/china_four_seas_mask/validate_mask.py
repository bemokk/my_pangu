from pathlib import Path
import json
import numpy as np
import shapely
from shapely.geometry import shape
import xarray as xr
import pandas as pd
from classify_buoys import classify
P=Path(__file__).resolve().parent
cases=[('synthetic_bohai',119.5,39,1),('synthetic_yellow',123.5,36,2),('synthetic_east',123,28,3),('synthetic_south',114,15,4),('synthetic_beibu',108,20,4),('synthetic_qiongzhou',110.3,20.15,4),('synthetic_taiwan_strait',120,24,4),('synthetic_taiwan_east',123,23,4),('synthetic_bashi',121.5,20,4),('synthetic_mainland',116.4,39.9,-1),('synthetic_taiwan_land',121,24,-1),('synthetic_pacific',132,28,0),('synthetic_invalid',999,28,-2),('synthetic_nan',float('nan'),28,-2)]
sid,aid,near,valid=classify([x[1] for x in cases],[x[2] for x in cases])
for case,got in zip(cases,sid):assert case[-1]==got,(case,got)
assert list(aid[6:9])==[1,2,3],aid
gs=[shape(f['geometry']) for f in json.loads((P/'four_seas_approx.geojson').read_text(encoding='utf-8'))['features']]
assert all(g.is_valid for g in gs)
overlap=max(gs[i].intersection(gs[j]).area for i in range(4) for j in range(i+1,4));assert overlap<1e-8
with xr.open_dataset(P/'four_seas_mask_0p05deg.nc') as ds:
    rng=np.random.default_rng(36109);ii=rng.integers(0,len(ds.lat),2000);jj=rng.integers(0,len(ds.lon),2000)
    a,b,_,_=classify(ds.lon.values[jj],ds.lat.values[ii]);assert np.array_equal(a,ds.sea_id.values[ii,jj]);assert np.array_equal(b,ds.aux_id.values[ii,jj])
    with np.load(P/'four_seas_mask_0p05deg.npz') as z:assert np.array_equal(z['sea_id'],ds.sea_id.values);assert np.array_equal(z['aux_id'],ds.aux_id.values)
assert int(classify(123,28)[0])==3
assert classify([],[])[0].size==0
df=pd.DataFrame(cases,columns=['id','longitude','latitude','expected_sea_id']);df['actual_sea_id']=sid;df['aux_id']=aid;df.to_csv(P/'synthetic_validation.csv',index=False,encoding='utf-8-sig')
df[['id','longitude','latitude']].to_csv(P/'example_synthetic_positions.csv',index=False,encoding='utf-8-sig')
(P/'validation_results.json').write_text(json.dumps({'valid_geometries':True,'no_area_overlap':True,'pairwise_overlap_deg2':overlap,'synthetic_positions':len(cases),'random_grid_checks':2000,'grid_vector_match':True,'npz_nc_match':True,'scalar_and_empty_arrays':True},indent=2))
print('Validation passed: synthetic positions, shared topology, 2000 grid points, file round-trip')
