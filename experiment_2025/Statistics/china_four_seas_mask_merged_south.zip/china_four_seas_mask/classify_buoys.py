"""CSV -> sea_id / sea_name / aux_id; approximate GB/T36109 four-sea mask.
pip install numpy shapely pandas
python classify_buoys.py buoys.csv --lon longitude --lat latitude --out results
"""
import argparse,json
from pathlib import Path
import numpy as np
import shapely
from shapely.geometry import shape
from shapely.affinity import scale
import pandas as pd
P=Path(__file__).resolve().parent
NAMES={-2:'无效坐标',-1:'陆地',0:'其他海域',1:'渤海',2:'黄海',3:'东海',4:'南海'}
AUX={0:'无',1:'台湾海峡',2:'台湾以东洋面',3:'巴士海峡'}
def classify(lon,lat,review_km=10.):
    """Return sea_id, aux_id, near_boundary, valid. Broadcast arrays/scalars.
    -2 invalid, -1 land, 0 other water, 1..4 four seas. Auxiliary tags 1..3
    apply within sea_id=4 as provenance subregions. Boundary points use lowest ID, land wins coast.
    Review distance is approximate at 20N and is NOT an error bound.
    """
    if not np.isfinite(review_km) or review_km<0:raise ValueError('review_km must be finite and >=0')
    x,y=np.broadcast_arrays(np.asarray(lon,float),np.asarray(lat,float));dims=x.shape
    x=x.ravel();y=y.ravel()
    valid=np.isfinite(x)&np.isfinite(y)&(x>=-180)&(x<=360)&(y>=-90)&(y<=90)
    x=np.where(x>180,x-360,x);x=np.where(valid,x,0);y=np.where(valid,y,0)
    sid=np.where(valid,0,-2).astype('int8');aid=np.zeros(x.shape,dtype='int8');near=np.zeros(x.shape,bool)
    def read(name):return [shape(f['geometry']) for f in json.loads((P/name).read_text(encoding='utf-8'))['features']]
    land=read('sources/land_context.geojson')[0];seas=read('four_seas_approx.geojson');aux=read('auxiliary_regions_approx.geojson')
    shapely.prepare(land);sid[valid&shapely.intersects_xy(land,x,y)]=-1
    for i,g in enumerate(seas):
        shapely.prepare(g);sid[(sid==0)&shapely.intersects_xy(g,x,y)]=i+1
    for i,g in enumerate(aux):
        shapely.prepare(g);aid[(sid==4)&(aid==0)&shapely.intersects_xy(g,x,y)]=i+1
    sx=111.32*np.cos(np.deg2rad(20));sy=111.32
    for g in seas:
        a,b,c,d=g.bounds
        pick=valid&(x>=a-review_km/sx)&(x<=c+review_km/sx)&(y>=b-review_km/sy)&(y<=d+review_km/sy)
        if np.any(pick):
            boundary=scale(g.boundary,xfact=sx,yfact=sy,origin=(0,0))
            near[pick]|=shapely.dwithin(boundary,shapely.points(x[pick]*sx,y[pick]*sy),review_km)
    return tuple(a.reshape(dims) for a in [sid,aid,near,valid])
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('csv',type=Path)
    ap.add_argument('--lon',default='longitude');ap.add_argument('--lat',default='latitude');ap.add_argument('--out',type=Path,default=Path('results'))
    ap.add_argument('--review-km',type=float,default=10.);ap.add_argument('--encoding',default='utf-8-sig');args=ap.parse_args()
    df=pd.read_csv(args.csv,encoding=args.encoding)
    fields=['sea_id','sea_name','aux_id','aux_name','near_boundary','valid_coordinates']
    if set(fields)&set(df.columns):raise ValueError('Input contains output column names')
    sid,aid,near,valid=classify(pd.to_numeric(df[args.lon],errors='coerce'),pd.to_numeric(df[args.lat],errors='coerce'),args.review_km)
    df['sea_id']=sid;df['sea_name']=[NAMES[int(i)] for i in sid];df['aux_id']=aid;df['aux_name']=[AUX[int(i)] for i in aid];df['near_boundary']=near;df['valid_coordinates']=valid
    args.out.mkdir(exist_ok=True,parents=True)
    df.to_csv(args.out/'all_classified.csv',encoding='utf-8-sig',index=False)
    for i in range(1,5):df[sid==i].to_csv(args.out/f'sea_{i}.csv',encoding='utf-8-sig',index=False)
    df[near].to_csv(args.out/'boundary_review.csv',encoding='utf-8-sig',index=False)
    df[sid<=0].to_csv(args.out/'unassigned_or_invalid.csv',encoding='utf-8-sig',index=False)
    print({NAMES[i]:int((sid==i).sum()) for i in NAMES})
if __name__=='__main__':main()
