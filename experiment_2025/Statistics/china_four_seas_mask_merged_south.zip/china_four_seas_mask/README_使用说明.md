# 四海统一分区掩膜

2026-11-05。按GB/T 36109—2018表2及图A.2的文字/示意范围构建，WGS84十进制度，经度在前、纬度在后。东海矢量几何沿用2026-10-28上一版。

**本成果是自制近似分析掩膜，用于浮标初筛。标准没有给出完整精确转折点坐标，本成果并非官方数字边界。** 各地名点坐标、岛链间折线和南海外围概化线均含分析者选择，不能声称逐点严格符合标准。北部湾、琼州海峡等四海汇总规则见下表。

## 同一份文件中的编码

NetCDF的`sea_id(lat,lon)`取值如下；NumPy版字段相同：

| sea_id | 含义 |
|---|---|
| -1 | 陆地 |
| 0 | 四个主海区以外的海域 |
| 1 | 渤海 |
| 2 | 黄海 |
| 3 | 东海 |
| 4 | 南海（含台湾海峡、台湾以东洋面、巴士海峡、北部湾和琼州海峡） |

CSV分类脚本另外用-2表示坐标无效。四海编号是本成果自定义的便捷编号，不是标准的业务区域代码。

同一NetCDF/NPZ内保留`aux_id`作为原细分区域的追溯标签：0=无，1=台湾海峡，2=台湾以东洋面，3=巴士海峡。**按用户指定，这三个原单列区域现已全部并入南海，主分类均为`sea_id=4`**。`aux_id`只用于追溯，不再表示独立于四海之外的分类。

这是用户指定的研究汇总口径，不是GB/T 36109—2018原始18个预报区的划分规定。更新后的南海矢量为原南海与三个原单列区的几何并集，渤海、黄海、东海几何均保持原样。原来海区之外的水面仍为0，不因这次合并而强行归类。

## 边界与汇总规则

| 区域 | 实现说明 |
|---|---|
| 渤海—黄海 | 老铁山角（约121.13E,38.72N）—蓬莱角（约120.75E,37.82N）直线；渤海海峡按该线两侧划入对应四海，不另作一个主类别 |
| 黄海—东海 | 启东角（约121.90E,31.70N）—济州岛西南角（约126.16E,33.20N）直线，两个海区共享该线 |
| 黄海北端/东侧 | 鸭绿江口附近和朝鲜半岛西岸；岛屿及沿岸水面按概化海岸数据处理 |
| 东海 | 完整沿用上一版；平潭岛—富贵角与台湾海峡分隔，台湾东北侧至岛链方向的南界为25N；东侧沿九州/琉球岛链方向概化 |
| 南海北部 | 原南海加上台湾海峡、台湾以东洋面、巴士海峡的并集；原南澳岛—鹅銮鼻线不再作为主分类的外边界。北部湾、琼州海峡也归南海 |
| 南海其他外边界 | 大陆/越南、马来半岛、苏门答腊、加里曼丹、菲律宾西侧方向，南至3S；半岛、岛屿和海峡间采用概化折线。泰国湾和苏禄海不作为本掩膜的主南海覆盖对象 |

全部手工控制点见`control_points.csv`；东海点位单列在`east_sea_control_points.csv`。表中坐标均为重建近似点，标准没有规定这些精确数字。CSV里含大陆/半岛内部闭合点，随后扣除陆地，不能将这些闭合点理解成海上边界。

海岸采用Natural Earth 1:10m land v5.1.1，**10m代表1:1000万比例尺，不是10米分辨率**。已扣除陆地和主要岛屿；小岛、河口、围填海及狭窄海峡细节可能不准确。海区包络扣除陆地后保留最大连通水面，再按编号优先级消除海区间面积重叠。

分类优先级：陆地优先，四海共线点按1→2→3→4顺序；随后在南海内部标记原细分区域。这使一条记录最多得到一个主海区编号。浮标正落在海岸轮廓上的点按陆地处理，应复核。

本掩膜是气象地理海区汇总，不进行领海或专属经济区裁切。

## 文件与用法

- `four_seas_approx.geojson`：一个文件含四个主海区要素，属性`sea_id`和`name_zh`；推荐用于浮标实际坐标判断。
- `four_seas_approx.shp/.shx/.dbf/.prj/.cpg`：同样的四海要素，五个文件一起使用，可载入QGIS/ArcGIS。
- `auxiliary_regions_approx.geojson`：保留的三个原细分区域，属性`parent_sea_id=4`表示均属于汇总后的南海。
- `four_seas_mask_0p01deg.nc/.npz`：0.01度规则网格，同一文件同时含sea_id和aux_id。
- `four_seas_mask_0p05deg.nc/.npz`：0.05度轻量规则网格，字段相同。
- `classify_buoys.py`：CSV浮标分类工具，也可导入`classify(lon,lat)`。
- `four_seas_preview.png`：范围预览。
- `build_mask.py`、`validate_mask.py`：重建和验证脚本。
- `sources/`：重建所需海岸数据、前版东海几何、官方标准表2/图A.2预览页及裁切陆地。

两套网格的覆盖范围均为99–133E、3S–42N，坐标为单元中心，纬度升序。海区以外为0，陆地为-1；网格外不得进行最近邻外推。0.01°或0.05°表示采样步长，**不是海区边界精度**。

安装CSV分类依赖：

```powershell
python -m pip install numpy pandas shapely
```

在本文件夹运行：

```powershell
python classify_buoys.py buoys.csv --lon longitude --lat latitude --out results
```

输出`all_classified.csv`含全部记录及中文海区名；`sea_1.csv`至`sea_4.csv`分别是四海记录；`boundary_review.csv`含边界附近内外两侧记录；`unassigned_or_invalid.csv`含其他水面、陆地和无效坐标。

经度接受-180…180或0…360，纬度-90…90；非数值/缺测/越界为无效。输入必须是WGS84十进制度，业务缺测码若落入合法数值范围应预先清理。漂流浮标按每条位置记录分类；同一浮标可能先后穿越多个海区。

```python
from classify_buoys import classify
sea_id, aux_id, near_boundary, valid = classify(lon_array, lat_array)
bohai_positions = observations[sea_id == 1]
east_sea_positions = observations[sea_id == 3]
```

```python
import xarray as xr
ds = xr.open_dataset('four_seas_mask_0p01deg.nc')
east_sea_mask = ds.sea_id == 3
```

数组与另一套模型网格不一致时，对目标格点经纬度重新执行分类，不要直接按数组下标相乘。

脚本默认给距四海主分类边界约10公里内的位置加`near_boundary`标记，可用`--review-km 30`扩大范围；原细分区域之间的内部边界不再单独触发该标记。距离用20N附近的经纬度线性换算，仅供提示；跨纬度区域误差随位置变化。**10公里不是误差界限**；外围岛链和海峡处的几何差异可能达到数十公里，严格筛选需复核业务矢量和原标准。

重建依赖：`python -m pip install numpy shapely pyshp scipy xarray matplotlib pandas`，然后运行`python build_mask.py --resolution 0.01`。已有sources时无需联网；所有源数据已随包附上。

## 来源与验证

1. GB/T36109—2018，表2、图A.2；官方入口：https://openstd.samr.gov.cn/bzgk/std/newGbInfo?hcno=213D318C8D7B8298ABBA88C34DE78697
2. 中国气象局发布的GB/T40153—2021表2将渤海、黄海、东海、南海及单列海峡分别编码，并要求范围按GB/T36109—2018表2：https://www.cma.gov.cn/zfxxgk/gknr/flfgbz/bz/202209/P020220921722111512618.pdf
3. Natural Earth land v5.1.1：https://www.naturalearthdata.com/downloads/10m-physical-vectors/10m-land/；源压缩包：https://naturalearth.s3.amazonaws.com/10m_physical/ne_10m_land.zip；公有领域条款：https://www.naturalearthdata.com/about/terms-of-use/

验证包括四海几何有效、无面积重叠、东海与前版一致、14个人工位置案例、2000个随机格点与逐坐标分类一致、NC/NPZ一致。见`validation_results.json`和`synthetic_validation.csv`。这些验证位置是人工样例，不是真实浮标资料；验证证明实现自洽，不证明概化边界达到官方精确程度。
