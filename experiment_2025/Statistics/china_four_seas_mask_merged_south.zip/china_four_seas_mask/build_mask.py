"""Approximate four-sea aggregation of GB/T36109-2018. No official vector.
Rebuild: pip install numpy shapely pyshp scipy xarray matplotlib pandas
python build_mask.py --resolution 0.05  (or 0.01)
"""
from pathlib import Path
import argparse,csv,json,shutil,zipfile
import numpy as np
import shapely,shapefile
from shapely.geometry import shape,mapping,Polygon,box
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
import xarray as xr

P=Path(__file__).resolve().parent; S=P/'sources';S.mkdir(exist_ok=True)
OLD=P.parent/'east_china_sea_gbt36109_2018'
for src,dst in [('sources/ne_10m_land.zip','ne_10m_land.zip'),('east_china_sea_gbt36109_approx.geojson','previous_east_sea.geojson'),('sources/gb_official_page_05.png','gb_table2.png'),('sources/gb_official_page_08.png','gb_fig_A2.png')]:
    if not (S/dst).exists():shutil.copy2(OLD/src,S/dst)
ap=argparse.ArgumentParser();ap.add_argument('--resolution',type=float,choices=[.01,.05],default=.05)
step=ap.parse_args().resolution
clip=box(98,-4,134,43)
lands=[]
with zipfile.ZipFile(S/'ne_10m_land.zip') as z:
    r=shapefile.Reader(shp=z.open('ne_10m_land.shp'),shx=z.open('ne_10m_land.shx'),dbf=z.open('ne_10m_land.dbf'))
    for s in r.iterShapes():
        a,b,c,d=s.bbox
        if c<98 or a>134 or d<-4 or b>43:continue
        lands.append(shapely.make_valid(shape(s.__geo_interface__)).intersection(clip))
land=unary_union(lands)
def clean(poly):
    g=shapely.make_valid(poly.difference(land))
    parts=[g] if g.geom_type=='Polygon' else [x for x in g.geoms if x.geom_type=='Polygon']
    return max(parts,key=lambda x:x.area)
L=(121.13,38.72);F=(120.75,37.82);Q=(121.90,31.70);J=(126.16,33.20)
N=(117.10,23.45);E=(120.85,21.90);T=(119.78,25.67);U=(121.535,25.30)
controls={
 'bohai':[F,L,(121.5,39),(122,40),(123,41),(123,42),(117,42),(115,38),(117,36),(120,36)],
 'yellow':[Q,(117,30),(115,35),(116,42),(125,42),(126,40.5),(124.35,39.78),(127,40),(128,39),(127.8,36),(127,34.5),(126.5,34.3),J],
 'south':[N,E,(121.1,20.8),(121,19),(120.85,18.6),(120.8,16),(121,13),(119.2,11.2),(118.7,10.5),(117.5,8),(116.7,6.5),(117,3),(114,0),(110,-3),(106,-3),(104,-1),(103.5,1),(102.5,3),(102.5,6),(104.75,8.6),(105.8,10),(106.5,16),(105.5,20),(106.5,23),(111,24)],
 'taiwan_strait':[T,U,(121.3,25.1),(121,24),(120.85,22.8),E,N,(116.5,24.5),(118.5,26.3)],
 'taiwan_east':[(121.96,25),(126.3,25),(124.3,22),(123,20.5),(121.1,20.8),E,(120.8,23.5),(121.5,25)],
 'bashi':[(121.1,20.8),(123,20.5),(122,18.5),(120.85,18.6),(121,19)],
}
bo=clean(Polygon(controls['bohai']))
ye=clean(Polygon(controls['yellow'])).difference(bo)
ea=shape(json.loads((S/'previous_east_sea.geojson').read_text(encoding='utf-8'))['features'][0]['geometry'])
ye=ye.difference(ea)
so=clean(Polygon(controls['south'])).difference(unary_union([bo,ye,ea]))
seas=[bo,ye,ea,so]
aux=[];used=unary_union(seas)
for key in ['taiwan_strait','taiwan_east','bashi']:
    g=clean(Polygon(controls[key])).difference(used);aux.append(g);used=used.union(g)
# User-requested aggregation: all three former auxiliary zones belong to South China Sea.
seas[3]=shapely.make_valid(unary_union([so,*aux]))
names=['渤海','黄海','东海','南海'];en=['bohai','yellow','east_china','south_china']
anames=['台湾海峡','台湾以东洋面','巴士海峡']
props={'standard':'GB/T36109-2018 Table 2 / Fig A.2','status':'approximate analyst reconstruction; NOT official digital boundary','date':'2026-11-05','crs':'EPSG:4326','coastline':'Natural Earth 1:10m v5.1.1 (scale 1:10,000,000, NOT 10 metres)','aggregation':'Beibu Gulf and Qiongzhou Strait included in South China Sea; Taiwan Strait / Taiwan east / Bashi merged into South China Sea by user request; aux_id retained as subregion provenance','boundary_rule':'covers; lower sea_id wins a shared line; primary seas before auxiliary zones'}
def writegeo(path,gs,ns,field):
    path.write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','properties':{**props,field:i+1,'name_zh':n,**({'parent_sea_id':4} if field=='aux_id' else {})},'geometry':mapping(g)} for i,(g,n) in enumerate(zip(gs,ns))]},ensure_ascii=False),encoding='utf-8')
writegeo(P/'four_seas_approx.geojson',seas,names,'sea_id')
writegeo(P/'auxiliary_regions_approx.geojson',aux,anames,'aux_id')
writegeo(S/'land_context.geojson',[land],['陆地'],'land_id')
with (P/'control_points.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['region','vertex','lon','lat','status'])
    for key,coords in controls.items():
        for i,(x,y) in enumerate(coords):w.writerow([key,i+1,x,y,'analyst approximate; inland closure points removed by land'])
shutil.copy2(OLD/'boundary_control_points.csv',P/'east_sea_control_points.csv')
w=shapefile.Writer(str(P/'four_seas_approx'),shapeType=shapefile.POLYGON,encoding='utf-8');w.field('sea_id','N',3);w.field('name_zh','C',30)
for i,g in enumerate(seas):
    parts=[g] if g.geom_type=='Polygon' else list(g.geoms);rings=[]
    for part in parts:
        part=orient(part,sign=-1);rings.extend([list(part.exterior.coords)]+[list(r.coords) for r in part.interiors])
    w.poly(rings);w.record(i+1,names[i])
w.close()
(P/'four_seas_approx.cpg').write_text('UTF-8')
(P/'four_seas_approx.prj').write_text('GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]]')
lon=np.round(np.arange(99+step/2,133,step),6);lat=np.round(np.arange(-3+step/2,42,step),6)
ids=np.zeros((len(lat),len(lon)),dtype='int8');aids=ids.copy()
for start in range(0,len(lat),80):
    xx,yy=np.meshgrid(lon,lat[start:start+80]);v=np.zeros(xx.shape,dtype='int8');a=v.copy()
    shapely.prepare(land);v[shapely.intersects_xy(land,xx,yy)]=-1
    for i,g in enumerate(seas):
        shapely.prepare(g);v[(v==0)&shapely.intersects_xy(g,xx,yy)]=i+1
    for i,g in enumerate(aux):
        shapely.prepare(g);a[(v==4)&(a==0)&shapely.intersects_xy(g,xx,yy)]=i+1
    ids[start:start+80]=v;aids[start:start+80]=a
tag=str(step).replace('.','p')+'deg'
ds=xr.Dataset({'sea_id':(('lat','lon'),ids),'aux_id':(('lat','lon'),aids),'crs':((),np.int32(0))},coords={'lon':lon,'lat':lat},attrs={'Conventions':'CF-1.8','title':'Approximate four-sea aggregation interpreted from GB/T36109-2018','date_created':'2026-11-05','status':props['status'],'aggregation':props['aggregation'],'resolution_degrees':step,'note':'cell centre sampling; use GeoJSON for buoy positions; sampling interval is not boundary accuracy'})
ds.lon.attrs.update(standard_name='longitude',units='degrees_east',axis='X');ds.lat.attrs.update(standard_name='latitude',units='degrees_north',axis='Y')
ds.sea_id.attrs.update(flag_values=np.array([-1,0,1,2,3,4],dtype='int8'),flag_meanings='land other_water bohai yellow_sea east_china_sea south_china_sea',grid_mapping='crs')
ds.aux_id.attrs.update(long_name='retained original subregion within aggregated South China Sea',flag_values=np.array([0,1,2,3],dtype='int8'),flag_meanings='none taiwan_strait taiwan_east bashi_channel',grid_mapping='crs')
ds.crs.attrs.update(grid_mapping_name='latitude_longitude',semi_major_axis=6378137.,inverse_flattening=298.257223563)
ds.to_netcdf(P/f'four_seas_mask_{tag}.nc',engine='scipy');np.savez_compressed(P/f'four_seas_mask_{tag}.npz',lon=lon,lat=lat,sea_id=ids,aux_id=aids)

import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MP
from matplotlib.patches import PathPatch,Patch
from matplotlib import font_manager
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']='Microsoft YaHei'
def draw(g,ax,color,edge='#6d767c',lw=.4):
    if g.geom_type!='Polygon':
        for q in g.geoms:
            if q.geom_type in ['Polygon','MultiPolygon']:draw(q,ax,color,edge,lw)
        return
    g=orient(g,1);vs=[];cs=[]
    for r in [g.exterior,*g.interiors]:
        v=list(r.coords);vs.extend(v);cs.extend([MP.MOVETO]+[MP.LINETO]*(len(v)-2)+[MP.CLOSEPOLY])
    ax.add_patch(PathPatch(MP(vs,cs),facecolor=color,edgecolor=edge,lw=lw))
colors=['#e99b61','#e5c75e','#6ab4cd','#8fbb8a']
fig,ax=plt.subplots(figsize=(9,11),dpi=170);ax.set_facecolor('#edf4f8');draw(land,ax,'#e3e0d7')
for g,c in zip(seas,colors):draw(g,ax,c,lw=.6)
for text,x,y in [('渤海',119.4,39.1),('黄海',123.5,36),('东海',124.3,28.5),('南海',114,14)]:ax.text(x,y,text,fontsize=14,ha='center',color='#34424a')
ax.set(xlim=(99,133),ylim=(-3,42),xlabel='经度 / °E',ylabel='纬度 / °N');ax.set_aspect(1/np.cos(np.deg2rad(20)))
ax.grid(alpha=.18);ax.set_axisbelow(True)
ax.set_title('渤海、黄海、东海、南海统一分区掩膜\n近似四海汇总：原单列辅助海区并入南海',loc='left',fontsize=15,pad=15)
ax.legend(handles=[Patch(facecolor=c,label=f'{i+1} {n}') for i,(n,c) in enumerate(zip(names,colors))],loc='lower left',fontsize=9)
fig.text(.12,.035,'WGS84；海岸线：Natural Earth 1:1000万；近似折线边界，供浮标初筛。\n按用户指定汇总：台湾海峡、台湾以东洋面、巴士海峡、北部湾与琼州海峡均归入南海。',fontsize=8.5,color='#586570')
fig.subplots_adjust(bottom=.12,top=.88);fig.savefig(P/'four_seas_preview.png');plt.close(fig)
summary={'valid':all(g.is_valid for g in seas+aux),'shape_lat_lon':ids.shape,'counts':{str(i):int((ids==i).sum()) for i in [-1,0,1,2,3,4]},'pairwise_overlap_deg2':max(seas[i].intersection(seas[j]).area for i in range(4) for j in range(i+1,4)),'east_sea_unchanged':ea.symmetric_difference(seas[2]).area==0}
assert summary['valid'] and summary['pairwise_overlap_deg2']<1e-8
(P/'build_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(summary)
